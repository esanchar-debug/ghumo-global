--
-- PostgreSQL database dump
--

\restrict ahiTX2EKfq0hOprNJdKrI4SnFzIlk3v99uFs1HlIcJG3d0LbEhr8t1DScsd0fc4

-- Dumped from database version 17.10 (4f20678)
-- Dumped by pg_dump version 17.10 (Ubuntu 17.10-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.itinerary_days DROP CONSTRAINT IF EXISTS itinerary_days_destination_id_fkey;
ALTER TABLE IF EXISTS ONLY public.stories DROP CONSTRAINT IF EXISTS stories_slug_key;
ALTER TABLE IF EXISTS ONLY public.stories DROP CONSTRAINT IF EXISTS stories_pkey;
ALTER TABLE IF EXISTS ONLY public.settings DROP CONSTRAINT IF EXISTS settings_pkey;
ALTER TABLE IF EXISTS ONLY public.itinerary_days DROP CONSTRAINT IF EXISTS itinerary_days_pkey;
ALTER TABLE IF EXISTS ONLY public.enquiries DROP CONSTRAINT IF EXISTS enquiries_pkey;
ALTER TABLE IF EXISTS ONLY public.destinations DROP CONSTRAINT IF EXISTS destinations_slug_key;
ALTER TABLE IF EXISTS ONLY public.destinations DROP CONSTRAINT IF EXISTS destinations_pkey;
ALTER TABLE IF EXISTS ONLY public.admin_tokens DROP CONSTRAINT IF EXISTS admin_tokens_pkey;
ALTER TABLE IF EXISTS public.stories ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.itinerary_days ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.enquiries ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.destinations ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.stories_id_seq;
DROP TABLE IF EXISTS public.stories;
DROP TABLE IF EXISTS public.settings;
DROP SEQUENCE IF EXISTS public.itinerary_days_id_seq;
DROP TABLE IF EXISTS public.itinerary_days;
DROP SEQUENCE IF EXISTS public.enquiries_id_seq;
DROP TABLE IF EXISTS public.enquiries;
DROP SEQUENCE IF EXISTS public.destinations_id_seq;
DROP TABLE IF EXISTS public.destinations;
DROP TABLE IF EXISTS public.admin_tokens;
DROP SCHEMA IF EXISTS public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_tokens (
    token text NOT NULL,
    type text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: destinations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.destinations (
    id integer NOT NULL,
    slug text NOT NULL,
    name text NOT NULL,
    region text NOT NULL,
    tagline text NOT NULL,
    summary text NOT NULL,
    image_url text NOT NULL,
    duration_label text NOT NULL,
    price_from integer NOT NULL,
    locations jsonb DEFAULT '[]'::jsonb NOT NULL,
    featured boolean DEFAULT false NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL
);


--
-- Name: destinations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.destinations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: destinations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.destinations_id_seq OWNED BY public.destinations.id;


--
-- Name: enquiries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.enquiries (
    id integer NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text,
    destination text,
    message text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: enquiries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.enquiries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: enquiries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.enquiries_id_seq OWNED BY public.enquiries.id;


--
-- Name: itinerary_days; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.itinerary_days (
    id integer NOT NULL,
    destination_id integer NOT NULL,
    day_number integer NOT NULL,
    title text NOT NULL,
    description text NOT NULL
);


--
-- Name: itinerary_days_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.itinerary_days_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: itinerary_days_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.itinerary_days_id_seq OWNED BY public.itinerary_days.id;


--
-- Name: settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.settings (
    key text NOT NULL,
    value text NOT NULL
);


--
-- Name: stories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stories (
    id integer NOT NULL,
    slug text NOT NULL,
    title text NOT NULL,
    excerpt text NOT NULL,
    content text NOT NULL,
    cover_image text NOT NULL,
    category text NOT NULL,
    author text NOT NULL,
    published boolean DEFAULT false NOT NULL,
    published_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: stories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stories_id_seq OWNED BY public.stories.id;


--
-- Name: destinations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.destinations ALTER COLUMN id SET DEFAULT nextval('public.destinations_id_seq'::regclass);


--
-- Name: enquiries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enquiries ALTER COLUMN id SET DEFAULT nextval('public.enquiries_id_seq'::regclass);


--
-- Name: itinerary_days id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.itinerary_days ALTER COLUMN id SET DEFAULT nextval('public.itinerary_days_id_seq'::regclass);


--
-- Name: stories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stories ALTER COLUMN id SET DEFAULT nextval('public.stories_id_seq'::regclass);


--
-- Data for Name: admin_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admin_tokens (token, type, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: destinations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.destinations (id, slug, name, region, tagline, summary, image_url, duration_label, price_from, locations, featured, sort_order) FROM stdin;
2	japan	Japan	international	Cherry blossoms & ancient temples.	From the neon canyons of Tokyo to the moss-stoned temples of Kyoto, this is Japan in its most cinematic form. Bullet trains, kaiseki dinners, and quiet ryokan mornings.	/img/dest-japan.png	8 nights	189000	["Tokyo", "Kyoto", "Osaka", "Mt. Fuji"]	t	2
3	united-kingdom	United Kingdom	international	Royal heritage & iconic skylines.	London's regal pulse, Edinburgh's ancient stone, the Cotswolds' golden villages — a refined journey through a kingdom of stories, gardens, and great trains.	/img/dest-uk.png	9 nights	245000	["London", "Cotswolds", "Edinburgh"]	t	3
4	dubai	Dubai & Abu Dhabi	international	Luxury, skyscrapers & desert magic.	Burj Khalifa sunsets, dune-bashing in the Liwa desert, and the white marble grandeur of Sheikh Zayed Mosque — a glittering crossroads of east and west.	/img/dest-dubai.png	5 nights	115000	["Dubai", "Abu Dhabi"]	t	4
5	switzerland	Switzerland	international	Alpine peaks & fairytale villages.	Glacier express trains, chocolate-box villages tucked into the Alps, and turquoise lakes that mirror sky — Switzerland is the storybook you remember from childhood.	/img/dest-switzerland.png	7 nights	215000	["Zurich", "Lucerne", "Interlaken", "Zermatt"]	t	5
6	thailand	Thailand	international	Temples, beaches & vibrant culture.	Bangkok's golden temples, the karst islands of Phang Nga Bay, and Chiang Mai's lantern-lit night markets. Spice, smile, and serenity in equal measure.	/img/dest-thailand.png	6 nights	92000	["Bangkok", "Phuket", "Krabi"]	f	6
8	italy	Italy	international	La dolce vita & Renaissance wonders.	Rome's ancient marble, Florence's quiet Renaissance courtyards, and the Amalfi coast's lemon-scented cliffs — a journey through history, cuisine, and pure beauty.	/img/dest-italy.png	9 nights	225000	["Rome", "Florence", "Venice", "Amalfi"]	f	8
9	maldives	Maldives	international	Private isles, glass-clear water.	Overwater villas, dolphin-flecked sunsets, and your own slice of coral atoll. The Maldives is the world's quietest indulgence.	/img/dest-maldives.png	5 nights	165000	["Male", "Baa Atoll"]	f	9
10	kerala	Kerala	domestic	Backwaters, spice & slow rivers.	Drift through the palm-lined backwaters on a private houseboat, breathe in the spice gardens of Munnar, and walk the colonial lanes of Fort Kochi.	/img/dest-kerala.png	6 nights	48000	["Kochi", "Munnar", "Alleppey"]	t	10
11	rajasthan	Rajasthan	domestic	Royal palaces & golden deserts.	Pink-walled Jaipur, blue-bathed Jodhpur, and golden Jaisalmer rising from the Thar desert. A royal procession through India's most cinematic state.	/img/dest-rajasthan.png	8 nights	65000	["Jaipur", "Jodhpur", "Udaipur", "Jaisalmer"]	t	11
12	himachal	Himachal Pradesh	domestic	Snow peaks & pine valleys.	Manali's apple orchards, Shimla's colonial Mall Road, and the snow-blanketed silence of Solang Valley. A Himalayan retreat for romantics and walkers alike.	/img/dest-himachal.png	6 nights	38000	["Shimla", "Manali", "Kasol"]	f	12
13	goa	Goa	domestic	Beaches, sunsets & sussegado.	Susegad afternoons, beach shacks at sunset, Portuguese mansions in old quarters, and the soft white sand of Palolem and Agonda.	/img/dest-goa.png	5 nights	32000	["North Goa", "South Goa"]	f	13
14	ladakh	Ladakh	domestic	Moonscapes & monasteries.	Pangong's electric blue waters, Nubra's twin-humped camels, and the silence of Hemis monastery — Ladakh is unlike anywhere else in India.	/img/dest-ladakh.png	7 nights	58000	["Leh", "Nubra", "Pangong"]	f	14
7	france	France	international	Eiffel lights & Riviera charm.	Paris in spring, Provence in lavender, the Cote d'Azur in summer — France is a slow seduction of bread, wine, and unhurried afternoons.	/img/dest-france.png	8 nights	198000	["Paris", "Loire Valley", "Nice"]	t	7
1	bali	Bali	international	Tropical paradise, slow days.	Lose yourself in the emerald rice terraces of Ubud, the surf breaks of Seminyak, and the soft turquoise lagoons of Nusa. Spa rituals, beach clubs, and sunset temple visits — all wrapped in warm Balinese hospitality.	/img/dest-bali.png	7 nights	58000	["Ubud", "Seminyak", "Nusa Dua"]	t	1
\.


--
-- Data for Name: enquiries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.enquiries (id, name, email, phone, destination, message, created_at) FROM stdin;
1	Pramod Kumar Mittal	esanchar@gmail.com	+919837116900	Goa	i need to book	2026-04-28 20:47:04.001585+00
2	Pramod Kumar Mittal	esanchar@gmail.com	+919837116900	Rajasthan	yryyry ddfgs	2026-04-28 20:48:34.084642+00
3	Pramod Kumar Mittal	esanchar@gmail.com	+919837116900	Himachal Pradesh	want to book this tour	2026-04-28 21:00:13.787673+00
4	Sourav	esanc@gmail.com	+919332100456	Kerala	Book this for june	2026-04-28 21:20:49.665003+00
5	Workflow Two 0619	workflow2-0619@example.com	+91 98765 20619	Switzerland	Demo readiness lead capture check for Switzerland. Please call after 5 PM.	2026-06-19 06:59:06.988547+00
6	API durability probe	api-probe@example.com	+919999999999	Switzerland	API direct persistence probe	2026-06-19 07:00:26.920112+00
7	Finder Workflow Test 0714	finder0714@example.com	+919999001714	Bali	Filtered finder enquiry test. Search was Bali, duration up to 8 days, max budget 50000.	2026-06-19 07:13:42.558852+00
8	Workflow2 Demo 0539	workflow2-0539@example.com	+919876543210	Switzerland	Demo readiness enquiry persistence check - unique message 0539.	2026-06-27 05:39:59.710842+00
9	Workflow2 API Verify 0540	workflow2-api-0540@example.com	+919876543210	Switzerland	Demo readiness persistence verification 0540.	2026-06-27 05:41:33.655577+00
10	Probe Submit 6531	probe6531@example.com	1234567890	Thailand	probe	2026-06-27 05:58:35.273039+00
11	Origin Probe 6533	origin6533@example.com	1234567890	Thailand	origin probe	2026-06-27 06:06:31.128788+00
\.


--
-- Data for Name: itinerary_days; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.itinerary_days (id, destination_id, day_number, title, description) FROM stdin;
1	1	1	Arrival in Denpasar — welcome to Ubud	Met on arrival at Ngurah Rai International Airport. Private transfer to your jungle resort in Ubud. Evening welcome dinner with traditional Balinese gamelan.
2	1	2	Ubud rice terraces & Tegalalang	Sunrise yoga session, breakfast overlooking the valley, then a guided walk through Tegalalang rice terraces and a visit to a local coffee plantation.
3	1	3	Sacred temples & Ubud markets	Tirta Empul holy spring temple ceremony, Gunung Kawi rock-cut shrines, and an afternoon exploring Ubud art markets and the Royal Palace.
4	1	4	Transfer to Seminyak — beach clubs & sunset	Drive south to Seminyak. Check in to a five-star beachfront resort. Sunset cocktails at Ku De Ta or Potato Head.
5	1	5	Seminyak surf & spa day	Optional morning surf lesson at Double Six Beach. Afternoon couples spa ritual and free time at the resort pool.
6	1	6	Nusa Dua — turquoise lagoons	Transfer to Nusa Dua. Snorkelling at Blue Lagoon, stand-up paddleboarding, and a private beach picnic.
7	1	7	Uluwatu cliffs & Kecak fire dance	Visit the dramatic Uluwatu temple at sunset. Traditional Kecak fire dance performance followed by a seafood dinner at Jimbaran Bay.
8	1	8	Departure	Leisurely breakfast and private transfer to the airport for your onward flight.
9	2	1	Arrival in Tokyo	Private transfer from Narita to your hotel in Shinjuku. Evening orientation walk through the lantern-lit alleys of Omoide Yokocho.
10	2	2	Tokyo classics	Senso-ji temple in Asakusa, the Imperial Palace gardens, and an afternoon in trendsetting Harajuku and Shibuya.
11	2	3	Mt. Fuji & Hakone	Day trip to Lake Kawaguchiko with iconic Fuji views, Hakone ropeway, and an onsen experience.
12	2	4	Bullet train to Kyoto	Shinkansen to Kyoto. Afternoon stroll through the Gion geisha district and dinner at a traditional kaiseki restaurant.
13	2	5	Kyoto temples & bamboo	Fushimi Inari shrine at sunrise, the Arashiyama bamboo grove, and the gold-leafed Kinkaku-ji temple.
14	2	6	Nara day trip	Visit the great Buddha at Todai-ji and feed the friendly deer of Nara Park. Return to Kyoto for a tea ceremony.
15	2	7	Osaka — street food capital	Travel to Osaka. Dotonbori food walk, Osaka Castle, and the rooftop observatory at Umeda Sky Building.
16	2	8	Free day & shopping	Free day to shop in Shinsaibashi or take an optional Universal Studios visit.
17	2	9	Departure	Transfer to Kansai airport for your departure flight.
18	3	1	Arrival in London	Private transfer from Heathrow. Evening Thames cruise with dinner under the bridges.
19	3	2	Royal London	Buckingham Palace changing of the guard, Westminster Abbey, and a Tower of London tour with a Beefeater guide.
20	3	3	British Museum & West End	Morning at the British Museum, afternoon shopping at Harrods, evening West End theatre show.
21	3	4	Cotswolds escape	Private chauffeur drive to Bibury, Bourton-on-the-Water, and Castle Combe. Stay at a country manor.
22	3	5	Oxford & Stratford	Tour Oxford colleges and Shakespeare's Stratford-upon-Avon.
23	3	6	Train to Edinburgh	First-class rail journey north. Evening walk along the Royal Mile.
24	3	7	Edinburgh Castle & whisky	Edinburgh Castle, Holyrood Palace, and a Scotch whisky tasting in the Old Town.
25	3	8	Loch Ness day trip	Travel through the Highlands to Loch Ness with a scenic boat ride.
26	3	9	Return to London	Fly back to London for a final shopping afternoon at Covent Garden.
27	3	10	Departure	Private transfer to Heathrow for your flight home.
28	4	1	Arrival in Dubai	Met on arrival, private transfer to Downtown hotel. Evening at The Dubai Mall and Burj Khalifa fountain show.
29	4	2	Modern Dubai tour	Burj Khalifa At The Top, Dubai Frame, and a yacht cruise around Palm Jumeirah.
30	4	3	Desert safari	Afternoon dune bashing, camel ride, henna painting, and BBQ dinner under the stars in a Bedouin camp.
31	4	4	Abu Dhabi day trip	Sheikh Zayed Grand Mosque, Louvre Abu Dhabi, and Ferrari World.
32	4	5	Old Dubai & souks	Spice and gold souks, abra ride across Dubai Creek, and the Al Fahidi historic district.
33	4	6	Departure	Free morning, then transfer to airport.
34	5	1	Arrival in Zurich	Met on arrival, transfer to your lakeside hotel. Evening walk through Bahnhofstrasse.
35	5	2	Zurich to Lucerne	Scenic train to Lucerne. Chapel Bridge, Lion Monument, and a paddle-steamer cruise on Lake Lucerne.
36	5	3	Mt. Pilatus excursion	Cogwheel railway, cable car, and lake combination tour up Mt. Pilatus.
37	5	4	Interlaken & Jungfraujoch	Train to Interlaken. Day trip to Jungfraujoch — Top of Europe — for snow play and panoramic views.
38	5	5	Zermatt & the Matterhorn	Glacier Express to Zermatt. Evening views of the Matterhorn from the village.
39	5	6	Gornergrat railway	Cogwheel ride to Gornergrat for unparalleled views of 29 peaks above 4,000m.
40	5	7	Return to Zurich	Scenic rail back to Zurich. Free evening for shopping and dining.
41	5	8	Departure	Transfer to Zurich airport.
42	6	1	Arrival in Bangkok	Private transfer to your riverside hotel. Evening Chao Phraya river dinner cruise.
43	6	2	Bangkok temples	Grand Palace, Wat Phra Kaew, Wat Pho reclining Buddha, and a long-tail boat tour of the canals.
44	6	3	Fly to Phuket	Morning flight to Phuket. Resort check-in and beach time at Patong.
45	6	4	Phi Phi islands tour	Speedboat tour of Phi Phi Don, Phi Phi Leh, Maya Bay, and Bamboo Island with snorkelling and lunch.
46	6	5	Krabi & James Bond Island	Day trip to Phang Nga Bay and the iconic James Bond Island.
47	6	6	Free day in Phuket	Optional spa, Big Buddha visit, or free time at the beach.
48	6	7	Departure	Transfer to Phuket airport.
49	7	1	Arrival in Paris	Private transfer from CDG. Evening Seine river cruise.
50	7	2	Paris highlights	Eiffel Tower, Arc de Triomphe, Champs-Elysees, and Sacre-Coeur.
51	7	3	Louvre & Latin Quarter	Skip-the-line Louvre tour, lunch in the Latin Quarter, Notre-Dame area walk.
52	7	4	Versailles day trip	Palace and gardens of Versailles, returning for an evening at Montmartre.
53	7	5	TGV to Nice	High-speed train to the French Riviera. Beachside hotel check-in.
54	7	6	Monaco & Eze	Day trip to Monaco, Monte Carlo casino, and the medieval village of Eze.
55	7	7	Cannes & Antibes	Riviera coastal drive, time at Cannes' La Croisette, and Picasso museum in Antibes.
56	7	8	Free day on the Riviera	Optional yacht charter or beach club day.
57	7	9	Departure	Transfer to Nice airport.
58	8	1	Arrival in Rome	Private transfer from Fiumicino. Evening passeggiata around Piazza Navona.
59	8	2	Ancient Rome	Colosseum, Roman Forum, Palatine Hill with an expert guide.
60	8	3	Vatican day	Vatican Museums, Sistine Chapel, and St. Peter's Basilica.
61	8	4	Train to Florence	Frecciarossa to Florence. Afternoon walk past the Duomo and Ponte Vecchio.
62	8	5	Florence museums	Uffizi Gallery, Accademia for the David, and a Tuscan dinner.
63	8	6	Tuscany wine tour	Day in Chianti countryside with vineyard lunch.
64	8	7	Venice arrival	Train to Venice. Evening gondola ride through the canals.
65	8	8	Venice islands	Murano glass-blowing, Burano lace-making, and St. Mark's Square.
66	8	9	Fly to Amalfi	Travel south to the Amalfi coast for a final luxury beach day.
67	8	10	Departure	Transfer to Naples airport.
68	9	1	Arrival & seaplane transfer	Met at Male airport. Scenic seaplane to your overwater villa.
69	9	2	House reef snorkelling	Guided snorkelling, paddleboarding, and a sunset dolphin cruise.
70	9	3	Spa & beach day	Couples massage at the overwater spa. Private beach picnic lunch.
71	9	4	Sandbank picnic	Boat to a private sandbank for champagne brunch and snorkelling.
72	9	5	Manta ray excursion	Seasonal snorkelling with manta rays in Hanifaru Bay.
73	9	6	Departure	Seaplane back to Male and onward flight.
74	10	1	Arrival in Kochi	Met at Kochi airport. Walk Fort Kochi's Chinese fishing nets and Jew Town.
75	10	2	Drive to Munnar	Scenic drive through tea plantations to Munnar.
76	10	3	Munnar tea trails	Tea museum, Eravikulam National Park, and Mattupetty dam.
77	10	4	Drive to Thekkady	Periyar wildlife sanctuary boat safari and a spice plantation walk.
78	10	5	Alleppey houseboat	Board your private houseboat for an overnight cruise through the backwaters.
79	10	6	Disembark & beach	Transfer to Marari beach for an afternoon of seaside relaxation.
80	10	7	Departure	Transfer to Kochi airport.
81	11	1	Arrival in Jaipur	Met at Jaipur airport. Welcome dinner at a heritage haveli.
82	11	2	Pink City tour	Amber Fort with elephant ride, City Palace, Hawa Mahal, and Jantar Mantar observatory.
83	11	3	Drive to Jodhpur	Long scenic drive via Pushkar, the holy lake town.
84	11	4	Mehrangarh Fort	Mehrangarh Fort tour, blue city walk, and a rooftop dinner.
85	11	5	Drive to Jaisalmer	Travel deeper into the Thar desert. Sunset on Sam dunes with camel ride.
86	11	6	Jaisalmer Fort	Living golden fort tour, Patwon ki Haveli, and a desert camp dinner.
87	11	7	Fly to Udaipur	Short flight to the city of lakes. Evening lake Pichola boat ride.
88	11	8	Udaipur palaces	City Palace, Jagdish temple, and a vintage car museum visit.
89	11	9	Departure	Transfer to Udaipur airport.
90	12	1	Arrival in Shimla	Met at Chandigarh, scenic drive to Shimla. Evening Mall Road walk.
91	12	2	Shimla sights	Christ Church, Jakhu Temple, and the Kufri snow point.
92	12	3	Drive to Manali	Long scenic drive along the Beas river to Manali.
93	12	4	Solang Valley	Snow activities, paragliding, and Atal tunnel sightseeing.
94	12	5	Old Manali & Kasol	Hadimba Devi temple, old Manali walk, and a day in the Israeli-flavoured village of Kasol.
95	12	6	Free day	Free morning for shopping, optional river rafting on the Beas.
96	12	7	Departure	Transfer to Bhuntar airport or onward to Chandigarh.
97	13	1	Arrival in Goa	Met at Goa airport. Evening at Baga or Calangute beach.
98	13	2	North Goa tour	Aguada Fort, Anjuna flea market, and Vagator beach sunset.
99	13	3	Old Goa heritage	Basilica of Bom Jesus, Se Cathedral, and the spice plantations of Ponda.
100	13	4	Drive to South Goa	Move to a quieter resort. Palolem beach evening.
101	13	5	Dolphin cruise & beach hop	Morning dolphin watching, then beach hopping through Agonda and Patnem.
102	13	6	Departure	Transfer to Goa airport.
103	14	1	Arrival in Leh	Met at Leh airport. Acclimatisation rest day at the hotel.
104	14	2	Leh sights & monasteries	Shanti Stupa, Leh Palace, Hemis monastery, and Thiksey monastery.
105	14	3	Drive to Nubra Valley	Cross Khardung La pass to the Nubra valley. Sand dunes and camel ride at Hunder.
106	14	4	Diskit & return to Leh	Visit Diskit monastery's giant Maitreya Buddha, then return drive to Leh.
107	14	5	Drive to Pangong Lake	Cross Chang La pass to reach Pangong. Overnight in lakeside camp.
108	14	6	Sunrise at Pangong & return	Sunrise photo session, then return to Leh via Shey palace.
109	14	7	Free day in Leh	Optional river rafting on the Indus or shopping in the main bazaar.
110	14	8	Departure	Transfer to Leh airport.
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.settings (key, value) FROM stdin;
philosophy2Title	People over postcards.
philosophy2Desc	The best moments come from local guides, family-run hotels, and conversations over chai.
philosophy3Title	Honest over salesy.
philosophy3Desc	If a season is wrong, a hotel is overrated, or a route is exhausting — we tell you.
contactEmail	contactus@ghumoglobal.com
address	Room No- 3G, 3rd Floor 18,\n  Rabindra Sarani, Poddar Court, Gate No. 03\n  Kolkata-700001
founderOneImage	
founderTwoName	Sundhangsu Jena
founderTwoTitle	Co-Founder & Operations Lead
founderTwoBio	Sundhangsu makes the impossible possible — from last-minute visa miracles to chartered flights when ash clouds ground the rest of the world. He leads the team that keeps every Ghumo journey running smoothly.
founderTwoImage	
navLogoUrl	
footerTagline	Curating extraordinary journeys for the discerning traveller.
aboutPageHeading	Designing journeys from Kolkata\nfor nearly two decades.
aboutPageIntro	Ghumo Global was founded in 2026 by two friends who believed Indian travellers deserved a better way to see the world. Eighteen years later, we've designed journeys for over eight thousand families — across forty airlines, twenty-eight countries, and one shared belief: travel done well changes a life.
aboutPhilosophyHeading	Four ideas that have guided us since day one.
philosophy1Title	Slow over packed.
philosophy1Desc	We'd rather you remember three perfect mornings than seventeen blurred sights.
philosophy4Title	Care after the goodbye.
philosophy4Desc	We answer your call at 3am from another time zone, because we've been on the road too.
contactPageHeading	Tell us where you'd like to go.
contactPageIntro	We answer every enquiry within 24 hours — usually with a few questions, sometimes with a draft itinerary, always with a real human on the other end.
servicesPageHeading	Everything we do, in service of the journey.
happyTravellers	8,500+
countriesCovered	28+
includedJson	[{"title":"Personalised Planning","desc":"A dedicated travel designer from day one to your last sunset."},{"title":"Trusted Partners","desc":"Two decades of vetted hotels, transport, and experience providers."},{"title":"Transparent Pricing","desc":"Itemised quotes, no hidden fees, and a price-match promise."},{"title":"On-Trip Care","desc":"A real human on call 24/7, in your timezone or ours."}]
processJson	[{"num":"01","title":"Discover","desc":"We listen — to where you've been, what you've loved, what you'd never do again."},{"num":"02","title":"Design","desc":"A draft itinerary in 48 hours, refined over a friendly conversation, not a sales pitch."},{"num":"03","title":"Confirm","desc":"We book and document everything — flights, hotels, visas, transfers, insurance."},{"num":"04","title":"Travel","desc":"You go. We watch from Kolkata, ready when you need us. We celebrate when you return."}]
faqsJson	[{"q":"How far in advance should I book?","a":"For long-haul international journeys (especially summer Europe, Christmas, and peak honeymoon months), we recommend reaching out 4–6 months ahead. Domestic and shorter trips can often be put together in 3–4 weeks. Last-minute is possible — we've pulled off Bali in 72 hours — but earlier always means better choice and pricing."},{"q":"How long does the visa process take?","a":"Visa timelines vary by country: Schengen typically 15 working days, UK and US 3–6 weeks, UAE/Singapore 3–5 working days. We handle the entire documentation and appointment process in-house, and we'll give you an honest, country-specific timeline before you pay your deposit."},{"q":"What are your payment terms?","a":"A 25% non-refundable deposit confirms your booking. The balance is due 30 days before departure for international trips, and 15 days before for domestic. We accept bank transfers, UPI, and major credit cards. EMI options are available on most cards for trips above ₹2 lakh."},{"q":"What is your cancellation policy?","a":"Cancellations more than 60 days before departure forfeit only the 25% deposit. Between 30–60 days, 50% of the trip cost is retained. Within 30 days, 100% is non-refundable — but we always work with our hotel and airline partners to recover whatever we can. We strongly recommend trip insurance, which we include in every quote."},{"q":"Are flights and hotels included in the price?","a":"All quoted prices are per person on twin-sharing basis and include international flights (economy, with upgrade options), 4 or 5-star accommodation, all transfers, daily breakfast, and listed sightseeing with English-speaking guides. Lunches, dinners, optional experiences, visa fees, and travel insurance are quoted separately so you can see exactly what you're paying for."},{"q":"Can you customise an existing itinerary?","a":"Absolutely — that's actually how most of our journeys are built. Use any itinerary on this site as a starting point, then tell us what to add, remove, lengthen, or upgrade. Want a helicopter transfer in Switzerland or a private chef night in Tuscany? Just ask."},{"q":"Do you offer support during the trip?","a":"Yes — every Ghumo traveller gets a direct WhatsApp line to a real human at our Kolkata office, available 24/7 in your timezone or ours. Lost luggage at midnight in Paris, a missed connection in Doha, a craving for Indian food in Tokyo — call us first. We've handled it before."},{"q":"Is travel insurance mandatory?","a":"It's mandatory for all our international journeys (and required for most visas). For domestic trips it's strongly recommended. Our comprehensive policy covers medical emergencies, trip cancellation, baggage loss, flight delays, and adventure activities like trekking and skiing. Premiums start around ₹1,500 per person for a standard 7-night Europe trip."}]
__admin_password_hash	$2b$12$Bek8pPihk/rLFk9hk7Obnu8sVT7CGJoniTO29n.dsOEmYyMZUIdJG
heroTitle	Travel the world, the Ghumo way.
heroSubtitle	From the boulevards of Paris to the backwaters of Kerala — international-standard luxury journeys, designed in Kolkata with warm Indian hospitality.
heroImage	/img/hero-switzerland.jpg
contactPhone	+91 7076332211
rating	4.9
yearsExperience	18+
journeyOfMonthSlug	italy
journeyOfMonthLabel	May 2026
homeAboutQuote	"We don't sell tours. We design memories that outlive us."
homeAboutBody	Born in Kolkata in 2026, Ghumo Global was founded by two travel-obsessed friends who believed Indian travellers deserved an agency that took the same care planning their honeymoon as their pilgrimage. Two decades later we run thousands of journeys a year — but each one still begins with a conversation, not a brochure.
homeAboutImage	
homeCTAHeading	Ready to plan your next journey?
homeCTABody	Tell us where you're dreaming of going. We'll come back within 24 hours with a draft itinerary and an honest quote.
founderOneName	Sourav Agarwal
founderOneTitle	Co-Founder & Itinerary Lead
founderOneBio	Sourav has personally walked over forty countries — from the bazaars of Marrakech to the back roads of Hokkaido. He builds the international journeys that have become Ghumo Global's signature.
servicesJson	[{"title":"Bespoke Itinerary Design","desc":"Day-by-day plans built around how you actually want to travel — not a template."},{"title":"Visa Assistance","desc":"End-to-end documentation, embassy appointments, and tracking across 60+ countries."},{"title":"Flight Bookings","desc":"Best-fare guarantees, premium-cabin upgrades, and multi-city routings handled in-house."},{"title":"Luxury Hotel Reservations","desc":"Direct relationships with five-star chains worldwide — preferential rates and welcome amenities."},{"title":"Private Transfers & Chauffeurs","desc":"Door-to-door private cars, English-speaking drivers, child seats on request."},{"title":"Experienced Tour Managers","desc":"Senior travel managers accompany select departures, every step of the way."},{"title":"Curated Experiences","desc":"Helicopter rides over Manhattan, private kaiseki dinners in Kyoto, hot-air balloons in Cappadocia."},{"title":"24/7 On-Trip Support","desc":"Direct WhatsApp line to a real human at our Kolkata office, day or night, any timezone."},{"title":"Travel Insurance","desc":"Comprehensive cover including trip cancellation, medical, lost baggage, and adventure activities."},{"title":"Honeymoon & Group Specialists","desc":"Dedicated teams for romance, milestones, large families, and corporate offsites."}]
travelStylesJson	[{"title":"Honeymoons","desc":"Intimate, design-forward escapes for the start of forever."},{"title":"Families","desc":"Multi-generational journeys with seamless logistics."},{"title":"Group Tours","desc":"Hand-picked small groups, departures throughout the year."},{"title":"Solo Discoveries","desc":"Independent travel with the safety of a dedicated team."}]
partnersJson	[]
\.


--
-- Data for Name: stories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stories (id, slug, title, excerpt, content, cover_image, category, author, published, published_at, created_at) FROM stdin;
1	first-light-in-bali	First light in Bali — a sunrise on the rim of Mt. Batur	We woke at three in the morning, wrapped ourselves in borrowed jackets, and climbed a volcano in the dark. Here is what waited for us at the top.	There is a particular silence that lives at 1,700 metres before dawn. We stepped out of our jeep at Mount Batur's trailhead in pitch black, the only sound a distant temple bell. Our guide pressed warm boiled eggs into our hands and pointed up.\n  \n  Three hours later, we sat on the volcanic rim with a thousand other strangers — yet it felt completely private. The sun came up behind Mount Agung, lighting the cloud floor pink, then orange, then gold. Below us, Lake Batur shimmered like spilled mercury.\n  \n  This is the Bali we plan for our travellers — not the cocktail bars of Seminyak, but the moments you remember on your deathbed.	/img/story-1.png	Field Notes	Sourav Agarwal	t	2026-04-28 06:36:01.827+00	2026-04-28 06:36:01.829086+00
2	kyoto-in-cherry-blossom-season	Kyoto in cherry blossom season — a guide to seeing it slowly	Hanami isn't a festival you attend. It's a frequency you tune into. Notes from ten days walking Kyoto in late March.	If you go to Kyoto in cherry blossom season expecting to tick off a list, you will leave exhausted and underwhelmed. The city is mobbed. The famous temples are full. The buses are slow.\n  \n  If you go to Kyoto expecting to slow down, you will find magic. We started each day before six, walking the Philosopher's Path while the petals were still wet with dew. We stopped at family-run cafes for hand-poured coffee and watched salarymen stop mid-commute to gaze at a single tree.\n  \n  The trick is to stay in a small machiya guest house in Higashiyama, eat at restaurants that don't have English menus, and accept that you will not see everything. Cherry blossom season is not a checklist. It is a meditation on impermanence.	/img/story-2.png	Destination Guides	Sundhangsu Jena	t	2026-04-28 06:36:01.831+00	2026-04-28 06:36:01.831431+00
3	desert-night-in-dubai	Desert night in Dubai — beyond the dune-bashing tour	Most Dubai desert tours feel like a theme park. Here is how we design a quieter, more intimate evening in the Liwa sands. There is a version of Dubai that most travelers never find. Not because it is hidden, exactly — but because it requires a willingness to slow down, to surrender the itinerary, and to let the ancient Rub' al Khali speak to something quieter inside you. This is that version. This is the desert after dark.	We have been to a hundred desert camps. Most of them are honestly forgettable — fluorescent lights, buffet food, a tired belly dancer. But the desert deserves better.\n  \n  For our luxury travellers, we book a private bedouin camp two hours into the Liwa desert. It sleeps eight. There is a chef who cooks lamb on hot stones. After dinner the staff disappear, leaving you alone with an oud player and a sky so dense with stars you could reach up and grab a handful.\n  \n  This is the Dubai we want you to remember — not the malls, but the quiet.	/img/story-3.png	Field Notes	Sourav Agarwal	t	2026-04-28 06:36:01.833+00	2026-04-28 06:36:01.83355+00
\.


--
-- Name: destinations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.destinations_id_seq', 15, true);


--
-- Name: enquiries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.enquiries_id_seq', 11, true);


--
-- Name: itinerary_days_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.itinerary_days_id_seq', 110, true);


--
-- Name: stories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stories_id_seq', 3, true);


--
-- Name: admin_tokens admin_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_tokens
    ADD CONSTRAINT admin_tokens_pkey PRIMARY KEY (token);


--
-- Name: destinations destinations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.destinations
    ADD CONSTRAINT destinations_pkey PRIMARY KEY (id);


--
-- Name: destinations destinations_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.destinations
    ADD CONSTRAINT destinations_slug_key UNIQUE (slug);


--
-- Name: enquiries enquiries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enquiries
    ADD CONSTRAINT enquiries_pkey PRIMARY KEY (id);


--
-- Name: itinerary_days itinerary_days_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.itinerary_days
    ADD CONSTRAINT itinerary_days_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (key);


--
-- Name: stories stories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stories
    ADD CONSTRAINT stories_pkey PRIMARY KEY (id);


--
-- Name: stories stories_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stories
    ADD CONSTRAINT stories_slug_key UNIQUE (slug);


--
-- Name: itinerary_days itinerary_days_destination_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.itinerary_days
    ADD CONSTRAINT itinerary_days_destination_id_fkey FOREIGN KEY (destination_id) REFERENCES public.destinations(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict ahiTX2EKfq0hOprNJdKrI4SnFzIlk3v99uFs1HlIcJG3d0LbEhr8t1DScsd0fc4

